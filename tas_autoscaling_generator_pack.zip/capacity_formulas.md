
# Advanced Capacity Formulas for TAS App Right-Sizing

## 1. CPU-Based Scaling
```
Estimated Instances = ceil((Average CPU % across instances) / Target CPU %)
Example: CPU Avg = 150%, Target = 75% → 2 instances
```

## 2. RPS-Based Scaling
```
Estimated Instances = ceil((Requests per Second) / Target RPS per instance)
Example: RPS = 400, Target per instance = 100 → 4 instances
```

## 3. Combined Logic
Use the **max** of CPU-based and RPS-based:
```
Estimated = max(CPU-based, RPS-based)
```

Optional: Add guardrails based on memory % or crash count.
