// This C# .NET 6 app includes:
// - CLI login interface with encrypted password storage
// - LDAP validation (configurable)
// - Web UI with foundation list, add form, and login action
// - Web UI protected via Bearer token (configurable)

// Program.cs - Entry Point
var builder = WebApplication.CreateBuilder(args);
builder.Services.AddRouting();

var app = builder.Build();
app.UseMiddleware<AuthMiddleware>();

// API: Get all foundations
app.MapGet("/api/foundations", () => Results.Json(FoundationStore.Load()));

// API: Add a new foundation
app.MapPost("/api/foundations", async (HttpContext context) =>
{
    var body = await new StreamReader(context.Request.Body).ReadToEndAsync();
    var json = JsonSerializer.Deserialize<Foundation>(body);
    if (json == null) return Results.BadRequest("Invalid body");

    json.EncryptedPassword = EncryptionUtil.Encrypt(json.EncryptedPassword);
    FoundationStore.Add(json);
    return Results.Ok();
});

// API: Trigger cf login
app.MapPost("/api/login", async (HttpContext context) =>
{
    var body = await new StreamReader(context.Request.Body).ReadToEndAsync();
    var req = JsonSerializer.Deserialize<Dictionary<string, string>>(body);
    if (req == null || !req.TryGetValue("name", out var name))
        return Results.BadRequest("Missing foundation name");

    var f = FoundationStore.Load().FirstOrDefault(x => x.Name == name);
    if (f == null) return Results.NotFound("Foundation not found");

    var pass = EncryptionUtil.Decrypt(f.EncryptedPassword);
    var psi = new ProcessStartInfo("cf", $"login -a {f.Api} -u {f.Username} -p {pass} --skip-ssl-validation")
    {
        RedirectStandardOutput = true,
        UseShellExecute = false
    };
    var proc = Process.Start(psi);
    await proc.WaitForExitAsync();

    return Results.Ok("Login attempted");
});

app.Run();
